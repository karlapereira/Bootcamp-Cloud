<?php
$accessKey = 'Access_key_ID';
$secretKey = 'Secret_access_key';
$region = 'us-east-1';
$bucket = 'NOME_DO_BUCKET';
$arqName =  'logo.jpg';
$linkestatico = 'http://pages.cloudtreinamentos.com/aws/arquivos'
?>
