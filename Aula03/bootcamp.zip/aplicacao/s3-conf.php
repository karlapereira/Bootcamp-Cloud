<?php
$accessKey = 'AKIAWTW2XFT6UCZUNJ64';
$secretKey = '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';
$region = 'us-east-1';
$bucket = 'myfirstbucket.bootcamp';
$arqName =  'logo.jpg';
$linkestatico = 'http://myfirstbucket.bootcamp.s3-website-us-east-1.amazonaws.com'
?>
